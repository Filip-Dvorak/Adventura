package util;

//soucast DU
public interface Observer {
    void update();
}
