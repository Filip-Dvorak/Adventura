package util;

public interface Observer {
    void update();
}
